package com.task.dialogueboxes.DialogueFragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.task.dialogueboxes.MainActivity;
import com.task.dialogueboxes.R;


public class MyDialogueFragment extends DialogFragment {
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("my Dialogue");
        builder.setMessage("Hii this is your message ");
        builder.setIcon(R.mipmap.ic_launcher);
//        builder.setPositiveButton("OK",new  DialogInterface.OnClickListener(){
//
//            @Override
//            public void onClick(DialogInterface dialogInterface, int i) {
//
////                Toast.makeText(MainActivity.this,"you have enter the OK button",Toast.LENGTH_LONG).show();
//            }
//        }
       return builder.create();
    }


}
