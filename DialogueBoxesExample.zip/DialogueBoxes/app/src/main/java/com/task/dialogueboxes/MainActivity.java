package com.task.dialogueboxes;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TimePicker;

import com.task.dialogueboxes.DialogueFragment.ListDialogue;
import com.task.dialogueboxes.DialogueFragment.ListDialogue_using_Adapter;
import com.task.dialogueboxes.DialogueFragment.MyDialogueFragment;
import com.task.dialogueboxes.DialogueFragment.TimePIckerFragment;

public class MainActivity extends AppCompatActivity {
    Button show;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.showDialogue).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                com.task.dialogueboxes.DialogueFragment.MyDialogueFragment myDialogueFragment = new MyDialogueFragment();
                myDialogueFragment.show(getSupportFragmentManager(), "hii");
            }
        });

//        @ TIMEPICKER

findViewById(R.id.timepicker).setOnClickListener(new View.OnClickListener() {
    @Override
  public void onClick(View view) {
//        TimePIckerFragment timePIckerFragment=new TimePIckerFragment();
//        ListDialogue listDialogue=new ListDialogue();
//        listDialogue.show(getSupportFragmentManager(),"list");
//        timePIckerFragment.show(getSupportFragmentManager(),"timePicker");
        ListDialogue_using_Adapter listDialogue_using_adapter=new ListDialogue_using_Adapter();
        listDialogue_using_adapter.show(getSupportFragmentManager(),"list");
   }
});
    }
}
