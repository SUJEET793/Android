package com.task.dialogueboxes.DialogueFragment;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.task.dialogueboxes.MainActivity;
import com.task.dialogueboxes.R;


public class ListDialogue extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("color picker");
         builder.setItems(R.array.mobile_company, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getContext(),"This is selected item",Toast.LENGTH_LONG).show();
                    }
                });
        return builder.create();
    }
}
